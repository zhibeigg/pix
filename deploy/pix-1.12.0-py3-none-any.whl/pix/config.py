"""统一的配置加载与合并。

优先级（后者覆盖前者）：
    默认值 < config.toml < .env < 环境变量 < CLI 显式传入参数
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Mapping

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover
    import tomli as tomllib  # type: ignore[no-redef]

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    def load_dotenv(*_args: Any, **_kwargs: Any) -> bool:  # type: ignore[misc]
        return False


# ---------- dataclass 定义 ----------


@dataclass
class ApiConfig:
    base_url: str = "https://www.packyapi.com"
    timeout: float = 180.0
    max_retries: int = 3
    # sora 分组 key，用于 gpt-image-2
    image_api_key: str | None = None
    # default 分组 key，用于 VL（Claude / Gemini / gpt-4o）
    vl_api_key: str | None = None


@dataclass
class ImageGenConfig:
    model: str = "gpt-image-2"
    size: str = "1024x1024"
    quality: str = "high"
    output_format: str = "png"
    # 图生图编辑时尽量保留原图主体和细节：low | high（Packy/OpenAI 兼容参数）
    edit_input_fidelity: str = "high"
    # 受控生图：默认让模型一次生成九宫格候选，后端再切图和抠动态纯色 key background。
    contact_sheet_enabled: bool = True
    contact_sheet_rows: int = 3
    contact_sheet_cols: int = 3
    green_screen_color: str = "auto"
    green_screen_tolerance: int = 48
    contact_sheet_prompt_template: str = (
        "Create a {rows}x{cols} contact sheet containing exactly {count} distinct variations of: {description}. "
        "Each cell contains one centered isolated game asset icon, consistent scale, clear spacing, no overlap. "
        "Use a pure solid key-color background {green} across the entire image for easy chroma-key removal. "
        "No text, no watermark, no UI frame, no labels, no extra props outside each item. "
        "Readable silhouette, high contrast, thick dark outline, pixel-art friendly details, "
        "designed to become a {width}x{height} RPG inventory sprite."
    )
    # Prompt guard 只审核用户原始输入，不把服务端模板暴露给模型。
    prompt_guard_enabled: bool = True
    prompt_guard_remote: bool = True
    prompt_guard_model: str = ""
    prompt_guard_failure_policy: str = "local"  # local | reject
    prompt_guard_max_chars: int = 500
    # 候选图评分：把切出的候选一次性送入 VL，按像素素材质量排序并选择最高分。
    candidate_vl_ranking_enabled: bool = True
    candidate_vl_ranking_model: str = ""
    candidate_vl_ranking_failure_policy: str = "first"  # first | reject
    # 候选生成策略：
    #   n_sample     —— 直接调用 n=N 让模型返回 N 张独立 full-res 图，每张单独抠色评分（默认）
    #   contact_sheet —— 旧路径：生成 RxC 九宫格再切图
    candidate_mode: str = "n_sample"
    # n-sample 候选数量；经验值 4 个；成本随 N 线性增长
    n_sample_count: int = 4
    # 若 provider 不支持 n=N 单次返回，fallback 循环调用时追加的 prompt 变体（非强约束，仅鼓励差异）
    n_sample_prompt_variations: list[str] = field(default_factory=lambda: [
        "slight variation in color tone.",
        "slight variation in lighting and highlight.",
        "slight variation in material texture emphasis.",
        "slight variation in silhouette pose.",
    ])
    # n-sample 单图 prompt 模板；与 contact_sheet_prompt_template 类似但不含 rows/cols
    n_sample_prompt_template: str = (
        "Create a single game asset icon of: {description}. "
        "One centered isolated object, consistent scale, clear spacing, no overlap. "
        "Use a pure solid key-color background {green} for easy chroma-key removal. "
        "No text, no watermark, no UI frame, no labels, no extra props outside the item. "
        "Readable silhouette, high contrast, thick dark outline, pixel-art friendly details, "
        "designed to become a {width}x{height} RPG inventory sprite."
    )


@dataclass
class VisionConfig:
    model: str = "claude-opus-4-7"
    temperature: float = 0.2
    max_tokens: int = 2048
    retry_on_parse: int = 1


@dataclass
class PixelizeConfig:
    output_size: tuple[int, int] = (128, 128)
    colors: int = 16
    dither: str = "floyd_steinberg"
    preset: str = "auto"
    preview_scale: int = 4
    edge_enhance: float = 0.1
    saturation: float = 1.0
    # 下采样模式：smart（自动对齐像素格）| box | bicubic | lanczos | nearest
    resample: str = "smart"
    # 是否在 smart 模式下尝试探测输入像素格并吸附到整数倍
    snap_to_grid: bool = True
    # 自动抠背景（flood-fill 从四角连通色）
    remove_bg: bool = False
    bg_tolerance: int = 12
    bg_feather: int = 0
    # 边缘风格：hard | feather | outline。bg_feather 表示对应强度。
    edge_style: str = "hard"
    # 自动裁剪主体，再缩小到目标像素尺寸
    auto_crop: bool = False
    crop_padding: float = 0.12
    crop_square: bool = True
    # 调色板策略：auto（保持原 K-means） | ramp（VL/本地色相阶梯） | kmeans（强制 K-means）
    palette_mode: str = "auto"


@dataclass
class AssetConfig:
    """游戏素材直出默认参数。"""

    output_dir: str = "图片"
    pixel_size: tuple[int, int] = (16, 16)
    colors: int = 12
    dither: str = "none"
    preview_scale: int = 12
    source_copy: bool = True
    image_quality: str = "low"
    skip_vl: bool = True
    remove_bg: bool = True
    bg_tolerance: int = 26
    bg_feather: int = 0
    auto_crop: bool = True
    crop_padding: float = 0.12
    crop_square: bool = True
    grid_mode: bool = True
    grid_json: bool = True
    grid_cleanup: bool = False
    grid_outline: bool = False
    grid_outline_strength: int = 1
    grid_min_neighbors: int = 1
    fit_canvas: bool = False
    fit_mode: str = "smart"
    fit_padding: int = 1
    fit_min_axis_coverage: float = 0.7
    # Asset 直出默认使用经典 K-means/auto 调色，贴近早期白底单图素材效果
    palette_mode: str = "auto"
    prompt_template: str = (
        "A single fantasy pixel game inventory item icon of {name}. "
        "Centered object, isolated on plain white background, no text, no UI frame, "
        "no shadow outside the item, thick dark outline, high contrast, readable silhouette, "
        "designed to become a {width}x{height} RPG inventory sprite."
    )


@dataclass
class SpriteConfig:
    """九宫格动画精灵表默认参数。"""

    output_dir: str = "图片/sprites"
    rows: int = 3
    cols: int = 3
    pixel_size: tuple[int, int] = (64, 64)
    colors: int = 16
    dither: str = "none"
    image_quality: str = "high"
    duration_ms: int = 120
    loop: int = 0
    green_screen_color: str = "auto"
    green_screen_tolerance: int = 48
    key_mode: str = "soft"
    key_softness: int = 120
    key_alpha_floor: int = 12
    key_despill: bool = True
    bg_tolerance: int = 26
    crop_padding: float = 0.12
    crop_square: bool = True
    shared_palette: bool = True
    prompt_template: str = (
        "Create a detailed pixel art animation contact sheet for a game: exactly {rows}x{cols} grid, "
        "{count} sequential animation keyframes. Animation subject/action: {description}. "
        "Read order is left-to-right, top-to-bottom. Keep the same character, camera angle, scale, "
        "anchor point and lighting in every cell. Each cell is one clean keyframe of the continuous motion, "
        "centered with enough padding, designed to become {width}x{height} game sprite frames. "
        "Use a pure solid key-color background {green} across the whole image for chroma-key removal. "
        "No text, no watermark, no labels, no numbers, no UI frame, no grid lines."
    )


@dataclass
class CacheConfig:
    enabled: bool = True
    dir: str = ".pix_cache"


@dataclass
class OutputConfig:
    root: str = "outputs"


@dataclass
class HistoryConfig:
    max_items: int = 200


@dataclass
class UiConfig:
    language: str = "zh-CN"


@dataclass
class AppConfig:
    api: ApiConfig = field(default_factory=ApiConfig)
    image_gen: ImageGenConfig = field(default_factory=ImageGenConfig)
    vision: VisionConfig = field(default_factory=VisionConfig)
    pixelize: PixelizeConfig = field(default_factory=PixelizeConfig)
    asset: AssetConfig = field(default_factory=AssetConfig)
    sprite: SpriteConfig = field(default_factory=SpriteConfig)
    cache: CacheConfig = field(default_factory=CacheConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    history: HistoryConfig = field(default_factory=HistoryConfig)
    ui: UiConfig = field(default_factory=UiConfig)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ---------- 合并 ----------


def _update_dataclass(obj: Any, values: Mapping[str, Any]) -> None:
    """浅层更新 dataclass 字段；未识别的字段静默忽略。"""
    if not values:
        return
    annotations = getattr(type(obj), "__annotations__", {})
    for key, value in values.items():
        if key not in annotations:
            continue
        current = getattr(obj, key, None)
        # 特殊处理 tuple[int, int]
        if isinstance(current, tuple) and isinstance(value, (list, tuple)):
            try:
                setattr(obj, key, tuple(int(v) for v in value))
            except (TypeError, ValueError):
                setattr(obj, key, current)
            continue
        # 特殊处理布尔（避免被 "false" 这种字符串误转）
        if isinstance(current, bool) and isinstance(value, str):
            setattr(obj, key, value.strip().lower() in ("1", "true", "yes", "on"))
            continue
        # 简单数值转换
        if isinstance(current, int) and not isinstance(value, bool) and isinstance(value, (int, float, str)):
            try:
                setattr(obj, key, int(value))
                continue
            except (TypeError, ValueError):
                pass
        if isinstance(current, float) and isinstance(value, (int, float, str)):
            try:
                setattr(obj, key, float(value))
                continue
            except (TypeError, ValueError):
                pass
        setattr(obj, key, value)


def _load_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fp:
        return tomllib.load(fp)


def _apply_mapping(cfg: AppConfig, data: Mapping[str, Any]) -> None:
    for section_name, section_values in data.items():
        if not isinstance(section_values, Mapping):
            continue
        section_obj = getattr(cfg, section_name, None)
        if section_obj is None:
            continue
        _update_dataclass(section_obj, section_values)


def _apply_env(cfg: AppConfig) -> None:
    """从环境变量覆盖关键字段。"""
    api_key = os.getenv("PACKY_API_KEY")
    vl_key = os.getenv("PACKY_VL_API_KEY") or api_key
    base_url = os.getenv("PACKY_BASE_URL")

    if api_key:
        cfg.api.image_api_key = api_key
    if vl_key:
        cfg.api.vl_api_key = vl_key
    if base_url:
        cfg.api.base_url = base_url


# ---------- 公共入口 ----------


def load_config(
    config_file: Path | str | None = None,
    overrides: Mapping[str, Any] | None = None,
    env_file: Path | str | None = ".env",
) -> AppConfig:
    """加载配置。

    Args:
        config_file: 可选 TOML 配置文件路径；默认检索 ./config.toml。
        overrides: CLI/GUI 传入的覆盖值，结构与 AppConfig 一致（section -> field -> value）。
        env_file: .env 路径，None 表示跳过。
    """
    # 1. 加载 .env
    if env_file is not None and not os.getenv("PIX_DISABLE_DOTENV"):
        env_path = Path(env_file)
        if env_path.exists():
            load_dotenv(env_path)
        else:
            load_dotenv()  # 尝试默认搜索

    cfg = AppConfig()

    # 2. 合并 config.toml
    candidate_paths: list[Path] = []
    if config_file is not None:
        candidate_paths.append(Path(config_file))
    else:
        candidate_paths.append(Path("config.toml"))
    for p in candidate_paths:
        _apply_mapping(cfg, _load_toml(p))

    # 3. 环境变量
    _apply_env(cfg)

    # 4. 显式 overrides
    if overrides:
        _apply_mapping(cfg, overrides)

    return cfg


def require_image_api_key(cfg: AppConfig) -> str:
    if not cfg.api.image_api_key:
        raise RuntimeError(
            "未找到 PACKY_API_KEY。请在 .env 中设置或导出环境变量。"
            "（gpt-image-2 需要 sora 分组的令牌）"
        )
    return cfg.api.image_api_key


def require_vl_api_key(cfg: AppConfig) -> str:
    key = cfg.api.vl_api_key or cfg.api.image_api_key
    if not key:
        raise RuntimeError(
            "未找到 PACKY_VL_API_KEY / PACKY_API_KEY。请在 .env 中设置 VL 分组令牌。"
        )
    return key
